# The purpuse of module 14 task 2 is to put the price of the products in descending order as shown on the screenshot.
# The purpuse of module 14 task 3 is to put the price of the products above $25 in ascending order.
